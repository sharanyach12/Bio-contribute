import 'package:bio_contribute/src/config/config.dart';
import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

final authServiceProvider = Provider<AuthServices>(
  (ref) => AuthServices(),
);

class LoginResult {
  final bool success;
  final String message;

  LoginResult(this.success, this.message);
}

class AuthServices {
  Dio dio = Dio();
  bool isLoggedIn = false;
  String? token;

  AuthServices() {
    // Initialize the token from SharedPreferences when the class is created.
    getTokenFromSharedPreferences().then((savedToken) {
      token = savedToken;
      isLoggedIn = token != null;
    });
  }

  Future<void> _saveTokenToSharedPreferences(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('userToken', token);
  }

  Future<String?> getTokenFromSharedPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('userToken');
  }

  Future<LoginResult> login(
      {required String email, required String password}) async {
    var url = Uri.parse("$baseUrl/login/").toString();

    var headers = <String, String>{
      'Accept': '*/*',
      'Content-Type': 'multipart/form-data',
    };

    FormData formData = FormData.fromMap({
      "email_address": email,
      "password": password,
    });

    try {
      var response = await dio.post(
        url,
        data: formData,
        options: Options(headers: headers),
      );

      if (response.statusCode == 202) {
        // Successful login
        // Gain access to token in response: here
        final data = response.data;
        token = data['token'];
        // Save the token to SharedPreferences
        if (token != null) {
          await _saveTokenToSharedPreferences(token!);
        }

        isLoggedIn = true;
        return LoginResult(true, "Login successful");
      } else if (response.statusCode == 401) {
        // Invalid credentials
        return LoginResult(false, "Invalid email or password");
      } else {
        // Handle other response codes here
        return LoginResult(false, "Error during login");
      }
    } catch (error) {
      if (error is DioException) {
        if (error.response != null && error.response!.statusCode == 401) {
          // Handle 401 Unauthorized as an error
          return LoginResult(false, "Invalid email or password");
        } else {
          // Handle other Dio errors
          return LoginResult(false, "Error during login");
        }
      }
      // Handle other errors
      return LoginResult(false, "Error during login");
    }
  }

  // Register User
  Future<LoginResult> register(
      {required String username,
      required String email,
      required String password}) async {
    var url = Uri.parse("$baseUrl/register/").toString();

    var headers = <String, String>{
      'Accept': '*/*',
      'Content-Type': 'multipart/form-data',
    };

    FormData formData = FormData.fromMap({
      "username": username,
      "email_address": email,
      "password": password,
    });

    try {
      var response = await dio.post(
        url,
        data: formData,
        options: Options(headers: headers),
      );

      if (response.statusCode == 201) {
        // Successful login
        // Gain access to token in response: here
        final data = response.data;
        token = data['token'];
        // Save the token to SharedPreferences
        if (token != null) {
          await _saveTokenToSharedPreferences(token!);
        }

        isLoggedIn = true;
        return LoginResult(true, "Login successful");
      } else if (response.statusCode == 401) {
        // Invalid credentials
        return LoginResult(false, "Invalid email or password");
      } else {
        // Handle other response codes here
        return LoginResult(false, "Error during login 1");
      }
    } catch (error) {
      if (error is DioException) {
        if (error.response != null && error.response!.statusCode == 401) {
          // Handle 401 Unauthorized as an error
          return LoginResult(false, "Invalid email or password");
        } else {
          final responseData = error.response?.data;
          if (responseData != null && responseData['email_address'] is List) {
            final errorList = responseData['email_address'] as List;
            if (errorList.isNotEmpty) {
              final errorMessage = errorList[0] as String;

              return LoginResult(false, errorMessage);
            }
          }
        }
      }
      // Handle other errors
      return LoginResult(false, "Error during login");
    }
  }
}
