import 'package:bio_contribute/src/config/config.dart';
import 'package:bio_contribute/src/models/user.dart';
import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class UserApiServices {
  Dio dio = Dio();

  Future<User?> getUser({required String token}) async {
    var url = Uri.parse("$baseUrl/get_user/").toString();
    var headers = <String, String>{
      'Accept': '*/*',
      'Content-Type': 'multipart/form-data',
      'Authorization': 'Token $token',
    };

    final response = await dio.get(url, options: Options(headers: headers));

    User user;

    if (response.statusCode == 200) {
      final data = response.data;
      user = User.fromJson(data);
      return user;
    } else {
      return null;
    }
  }

  Future<bool> deleteUser({required String token}) async {
    var url = Uri.parse("$baseUrl/delete_user/").toString();
    var headers = <String, String>{
      'Accept': '*/*',
      'Content-Type': 'multipart/form-data',
      'Authorization': 'Token $token',
    };

    try {
      final response =
          await dio.delete(url, options: Options(headers: headers));

      if (response.statusCode == 200 || response.statusCode == 201) {
        return true;
      } else {
        return false;
      }
    } catch (error) {
      // Handle any errors here
      return false;
    }
  }
}

final userProvider = Provider<UserApiServices>((ref) => UserApiServices());
