import 'dart:io';

import 'package:bio_contribute/src/config/config.dart';
import 'package:bio_contribute/src/models/comment.dart';
import 'package:bio_contribute/src/models/specimen.dart';
import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class SpecimenApiServices {
  Dio dio = Dio();

  List<Specimen> allSpecimen = [];

  Future<List<Specimen>> getAllSpecimen() async {
    allSpecimen.clear();

    var url = Uri.parse(baseUrl).toString();

    var headers = <String, String>{
      // 'Accept': 'application/json',
      // 'Content-Type': 'application/json',
      // 'Authorization': 'Bearer $bearerToken'
    };
    // ...

    final response = await dio.get(url, options: Options(headers: headers));

    if (response.statusCode == 200) {
      final data = response.data;
      for (var specimenData in data) {
        Specimen specimen = Specimen.fromJson(specimenData);
        allSpecimen.add(specimen);
      }
      return allSpecimen;
    } else {
      return [];
    }
  }

  Future<bool> postSpecimen(
      Specimen specimen, File imageFile, String token) async {
    String fileName = imageFile.path.split('/').last;
    try {
      // Create a FormData object for the request
      FormData formData = FormData.fromMap({
        'name': specimen.name,
        'description': specimen.description,
        'image': await MultipartFile.fromFile(
          imageFile.path,
          filename: fileName,
        ),
        'latitude': specimen.latitude?.toStringAsFixed(6),
        'longitude': specimen.longitude?.toStringAsFixed(6),
      });
      var url = Uri.parse("$baseUrl/create/").toString();

      Map<String, String> headers = {
        'Accept': '*/*',
        'Content-Type': 'multipart/form-data',
        "Authorization": "Token $token"
      };

      final response = await dio.post(
        url,
        data: formData,
        options: Options(
          headers: headers,
          // contentType: 'multipart/form-data',
        ),
      );

      if (response.statusCode == 201) {
        // Handle a successful response

        return true;
      } else {
        // Handle other response statuses as needed

        return false;
      }
    } catch (error) {
      if (error is DioException) {
        print(error.response?.statusCode);
        print(error.response?.data);
        return false;
      }
      return false;
    }
  }

  Future<bool> updateSpecimen(
      Specimen specimen, File? imageFile, String token) async {
    try {
      final formData = FormData.fromMap({
        'id': specimen.id,
        'name': specimen.name,
        'description': specimen.description,
        if (imageFile != null)
          'image': await MultipartFile.fromFile(
            imageFile.path,
            filename: imageFile.path.split('/').last,
          ),
        'latitude': specimen.latitude?.toStringAsFixed(6),
        'longitude': specimen.longitude?.toStringAsFixed(6),
      });

      final url = Uri.parse("$baseUrl/update/").toString();

      final headers = {
        'Accept': '*/*',
        'Content-Type': 'multipart/form-data',
        'Authorization': "Token $token",
      };

      final response = await dio.put(
        url,
        data: formData,
        options: Options(
          headers: headers,
        ),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        return true;
      } else {
        return false;
      }
    } catch (error) {
      if (error is DioException) {
        return false;
      }
      return false;
    }
  }

  Future<bool> deleteSpecimen(Specimen specimen, String token) async {
    // String fileName = imageFile.path.split('/').last;
    try {
      // Create a FormData object for the request
      FormData formData = FormData.fromMap({
        'id': specimen.id,
      });
      var url = Uri.parse("$baseUrl/delete/").toString();

      Map<String, String> headers = {
        'Accept': '*/*',
        'Content-Type': 'multipart/form-data',
        "Authorization": "Token $token"
      };

      final response = await dio.delete(
        url,
        data: formData,
        options: Options(
          headers: headers,
          // contentType: 'multipart/form-data',
        ),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        // Handle a successful response

        return true;
      } else {
        // Handle other response statuses as needed

        return false;
      }
    } catch (error) {
      if (error is DioException) {
        return false;
      }
      return false;
    }
  }

  // Comments Section

  Future<Comment?> postComment(
      {required int specimenId,
      required String comment,
      required String token}) async {
    try {
      // Create a FormData object for the request
      FormData formData = FormData.fromMap({
        'specimen_id': specimenId,
        'comment': comment,
      });
      var url = Uri.parse("$baseUrl/create_comment/").toString();

      Map<String, String> headers = {
        'Accept': '*/*',
        'Content-Type': 'multipart/form-data',
        "Authorization": "Token $token"
      };

      final response = await dio.post(
        url,
        data: formData,
        options: Options(
          headers: headers,
        ),
      );

      if (response.statusCode == 201) {
        // Handle a successful response
        Comment newComment = Comment.fromJson(response.data);
        return newComment;
      } else {
        // Handle other response statuses as needed

        return null;
      }
    } catch (error) {
      if (error is DioException) {
        print(error.response?.statusCode);
        print(error.response?.data);
        return null;
      }
      return null;
    }
  }

  Future<bool> deleteComment(String commentId, String token) async {
    // String fileName = imageFile.path.split('/').last;
    try {
      // Create a FormData object for the request
      FormData formData = FormData.fromMap({
        'id': commentId,
      });
      var url = Uri.parse("$baseUrl/delete_comment/").toString();

      Map<String, String> headers = {
        'Accept': '*/*',
        'Content-Type': 'multipart/form-data',
        "Authorization": "Token $token"
      };

      final response = await dio.delete(
        url,
        data: formData,
        options: Options(
          headers: headers,
          // contentType: 'multipart/form-data',
        ),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        // Handle a successful response

        return true;
      } else {
        // Handle other response statuses as needed

        return false;
      }
    } catch (error) {
      if (error is DioException) {
        return false;
      }
      return false;
    }
  }
}

final specimenProvider =
    Provider<SpecimenApiServices>((ref) => SpecimenApiServices());
