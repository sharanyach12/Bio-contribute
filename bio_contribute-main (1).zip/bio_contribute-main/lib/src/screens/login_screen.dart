import 'package:bio_contribute/src/constants/input_decorations.dart';
import 'package:bio_contribute/src/constants/size_box.dart';
import 'package:bio_contribute/src/constants/text_styles.dart';
import 'package:bio_contribute/src/provider/auth_provider.dart';
import 'package:bio_contribute/src/screens/sign_up_screen.dart';
import 'package:bio_contribute/src/themes/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool isObscure = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                gapH30,
                SizedBox(
                  height: 66,
                  child: SvgPicture.asset(
                    "assets/images/logo.svg",
                    semanticsLabel: 'Proceed Logo',
                  ),
                ),
                gapH30,
                gapH30,
                const Text(
                  "LOG IN",
                  style: kTitleStyle,
                ),
                gapH30,
                gapH20,
                const Align(
                  alignment: Alignment.bottomLeft,
                  child: Text("Email"),
                ),
                gapH5,
                SizedBox(
                  child: TextFormField(
                    decoration: tFieldInputDecoration(),
                    controller: emailController,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return ("Plese Enter Your Email");
                      }
                      // reg expression for email validation
                      if (!RegExp("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+.[a-z]")
                          .hasMatch(value)) {
                        return ("Please Enter a valid email");
                      }
                      return null;
                    },
                  ),
                ),
                gapH10,
                const Align(
                  alignment: Alignment.bottomLeft,
                  child: Text("Password"),
                ),
                gapH5,
                TextFormField(
                  decoration: tFieldInputDecoration(
                    suffixIcon: IconButton(
                      onPressed: () {
                        setState(() {
                          isObscure = !isObscure;
                        });
                      },
                      icon: Icon(
                        isObscure ? Icons.visibility : Icons.visibility_off,
                      ),
                    ),
                  ),
                  controller: passwordController,
                  obscureText: isObscure,
                  enableSuggestions: false,
                  autocorrect: false,
                  validator: (value) {
                    RegExp regex = RegExp(r'^.{8,}$');
                    if (value!.isEmpty) {
                      return ("Password is required to login");
                    }
                    if (!regex.hasMatch(value)) {
                      return ("Enter valid password(Min: 8 Character)");
                    }
                    return null;
                  },
                ),
                gapH20,
                Consumer(builder: (context, ref, _) {
                  bool isLoading = ref.watch(authNotifierProvider);
                  return isLoading
                      ? const SpinKitWaveSpinner(
                          color: myForeGroundColor,
                          size: 50.0,
                        )
                      : InkWell(
                          onTap: () {
                            if (_formKey.currentState!.validate()) {
                              ref.read(authNotifierProvider.notifier).login(
                                  email: emailController.text,
                                  password: passwordController.text,
                                  context: context);
                            }
                          },
                          child: SvgPicture.asset(
                            "assets/images/proceed.svg",
                            semanticsLabel: 'Proceed Logo',
                          ),
                        );
                }),
                gapH30,
                GestureDetector(
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) {
                      return const SignUpScreen();
                    }));
                  },
                  child: const SizedBox(
                    height: 20,
                    child: Text.rich(
                      TextSpan(
                        text: "Don't have an account? ",
                        children: [
                          TextSpan(
                            text: "Register.",
                            style: TextStyle(
                              color:
                                  myForeGroundColor, // Set the custom color for "Register"
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
