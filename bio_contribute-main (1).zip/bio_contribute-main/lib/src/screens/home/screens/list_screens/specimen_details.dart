import 'package:bio_contribute/src/models/comment.dart';
import 'package:bio_contribute/src/models/user.dart';
import 'package:bio_contribute/src/provider/specimen_provider.dart';
import 'package:bio_contribute/src/provider/user_provider.dart';
import 'package:bio_contribute/src/screens/home/screens/capture_screens/update_specimen/update_specimen.dart';
import 'package:bio_contribute/src/services/auth_services.dart';
import 'package:bio_contribute/src/services/specimen_api_services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:bio_contribute/src/constants/input_decorations.dart';
import 'package:bio_contribute/src/models/specimen.dart';
import 'package:bio_contribute/src/screens/home/screens/list_screens/view_on_map.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:intl/intl.dart';

import '../../../../config/config.dart';
import '../../../../constants/size_box.dart';
import '../../../../themes/colors.dart';

class SpecimenDetails extends StatefulWidget {
  const SpecimenDetails({
    super.key,
    required this.specimen,
    required this.heroTag,
  });

  final Specimen specimen;
  final String heroTag;

  @override
  State<SpecimenDetails> createState() => _SpecimenDetailsState();
}

class _SpecimenDetailsState extends State<SpecimenDetails> {
  late List<Comment> comments;
  final TextEditingController commentController = TextEditingController();
  late String heroTag;
  late Specimen specimen;

  @override
  void initState() {
    super.initState();
    // Initialize your comments list with the specimen's comments
    comments = widget.specimen.comments ?? [];
    heroTag = widget.heroTag;
    specimen = widget.specimen;
  }

  @override
  void dispose() {
    commentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer(builder: (context, ref, child) {
      final userData = ref.watch(userDataProvider);
      // Retrieve the entire User object
      User? currentUser = userData.maybeWhen(
        orElse: () => null,
        data: (data) => data,
      );

      return Scaffold(
        appBar: AppBar(
          backgroundColor: myBackGroundColor,
          foregroundColor: myForeGroundColor,
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                SizedBox(
                  height: 200,
                  width: double.infinity,
                  child: ClipRRect(
                    borderRadius: const BorderRadius.all(
                      Radius.circular(20),
                    ),
                    child: Hero(
                      tag: heroTag,
                      child: CachedNetworkImage(
                        imageUrl: "$baseUrl${specimen.imageUrl}",
                        progressIndicatorBuilder:
                            (context, url, downloadProgress) => Center(
                          child: CircularProgressIndicator(
                              value: downloadProgress.progress),
                        ),
                        errorWidget: (context, url, error) =>
                            const Icon(Icons.error),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
                gapH10,
                Text(
                  specimen.name,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                gapH5,
                Text(
                  specimen.description,
                ),
                gapH30,
                InkWell(
                  onTap: () async {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (builder) {
                      return ViewonMap(
                        latitude: specimen.latitude ?? 37.422,
                        longitude: specimen.longitude ?? -122.084,
                      );
                    }));
                  },
                  child: Container(
                    height: 55,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      image: const DecorationImage(
                        image: AssetImage("assets/images/pin_on_map.png"),
                        fit: BoxFit.cover,
                      ),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.location_on_outlined,
                          color: Colors.white,
                        ),
                        gapW5,
                        Text(
                          "view on map",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                gapH20,
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Column(
                      children: [
                        Text.rich(
                          TextSpan(
                            style: const TextStyle(
                              color: Colors.grey,
                            ),
                            children: [
                              const TextSpan(text: "Posted by ~ "),
                              TextSpan(text: specimen.creator?.authorName ?? '')
                            ],
                          ),
                        ),
                        Text.rich(
                          TextSpan(
                            style: const TextStyle(
                              color: Colors.grey,
                            ),
                            children: [
                              const TextSpan(text: "Captured on: "),
                              TextSpan(
                                text: formatDateTime(
                                    specimen.createdAt.toString()),
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                gapH20,
                Visibility(
                  visible: specimen.creator!.authorEmailAddress ==
                      currentUser?.email,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      TextButton(
                        onPressed: () {
                          Navigator.push(context,
                              MaterialPageRoute(builder: (context) {
                            return UpdateScreen(specimen: specimen);
                          }));
                        },
                        style: buttonStyleEdit(),
                        child: const Row(
                          children: [
                            Icon(
                              Icons.edit,
                              size: 20,
                            ),
                            gapW5,
                            Text('Edit '),
                          ],
                        ),
                      ),
                      gapW20,
                      TextButton(
                        onPressed: () {
                          bool isDeleting =
                              false; // Track the delete operation state

                          showDialog(
                            context: context,
                            barrierDismissible:
                                false, // Prevent dismissing dialog while loading
                            builder: (BuildContext context) {
                              return StatefulBuilder(
                                builder: (context, setState) {
                                  return AlertDialog(
                                    backgroundColor: myBackGroundColor,
                                    title: const Text("Delete Specimen"),
                                    content: isDeleting
                                        ? const SizedBox(
                                            height: 60,
                                            child: Center(
                                              child: SpinKitRing(
                                                lineWidth: 2,
                                                color: myForeGroundColor,
                                                size: 50.0,
                                              ),
                                            ),
                                          )
                                        : const Text(
                                            "Are you sure you want to delete this specimen?"),
                                    actions: <Widget>[
                                      TextButton(
                                        child: const Text(
                                          "Cancel",
                                        ),
                                        onPressed: () {
                                          if (!isDeleting) {
                                            Navigator.of(context).pop();
                                          }
                                        },
                                      ),
                                      TextButton(
                                        child: const Text("OK"),
                                        onPressed: () async {
                                          setState(() {
                                            isDeleting =
                                                true; // Show the progress indicator
                                          });
                                          final authServices =
                                              ref.read(authServiceProvider);
                                          String? token = authServices.token;

                                          bool isDeleted = await ref
                                              .read(specimenProvider)
                                              .deleteSpecimen(
                                                  specimen, token ?? '');

                                          if (!context.mounted) {
                                            return;
                                          }

                                          setState(() {
                                            isDeleting =
                                                false; // Hide the progress indicator
                                          });

                                          Navigator.of(context).pop();

                                          if (isDeleted) {
                                            ref.invalidate(
                                                specimenDataProvider);
                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(
                                              const SnackBar(
                                                content: Text(
                                                    "Specimen deleted successfully."),
                                              ),
                                            );
                                            Navigator.of(context).pop();
                                          } else {
                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(
                                              const SnackBar(
                                                content: Text(
                                                    "Failed to delete the specimen."),
                                              ),
                                            );
                                          }
                                        },
                                      ),
                                    ],
                                  );
                                },
                              );
                            },
                          );
                        },
                        style: buttonStyleEdit(),
                        child: const Row(
                          children: [
                            Icon(
                              Icons.delete,
                              size: 20,
                            ),
                            gapW5,
                            Text('Delete'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                gapH20,
                // Comment Input Field
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        decoration: addCommentDecoration(),
                        controller: commentController,
                        autofocus: false,
                      ),
                    ),
                    gapW5,
                    TextButton(
                      onPressed: () {
                        // Handle comment submission

                        if (commentController.text.isNotEmpty) {
                          // If both name and image are valid, proceed with the post operation
                          showDialog(
                            context: context,
                            builder: (context) => const AlertDialog(
                              backgroundColor: myBackGroundColor,
                              content: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  SpinKitRing(
                                    color: myForeGroundColor,
                                    lineWidth: 2,
                                  ),
                                  SizedBox(height: 16),
                                  Text("Posting comment..."),
                                ],
                              ),
                            ),
                            barrierDismissible: false,
                          );
                          // Gain access to the token
                          final authServices = ref.read(authServiceProvider);
                          String? token = authServices.token;

                          // Call the postSpecimen method
                          ref
                              .read(specimenProvider)
                              .postComment(
                                specimenId: specimen.id!,
                                comment: commentController.text,
                                token: token ?? '',
                              )
                              .then((newComment) {
                            // Dismiss loading dialog
                            Navigator.of(context).pop();
                            if (newComment != null) {
                              // Navigate to the home screen on success
                              ref.invalidate(specimenDataProvider);
                              // When adding a new comment
                              setState(() {
                                // Add the new comment at the start of the list
                                comments.insert(0, newComment);
                              });

                              // Clear the input field
                              commentController.clear();
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  backgroundColor: Colors.green,
                                  content: Text("Posted Comment Successfully!"),
                                ),
                              );
                            } else {
                              // Handle the failure, you can show an error message here
                              // or handle it as per your requirements
                              // For example, show a SnackBar with an error message
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                      "Failed to post comment. Please try again."),
                                ),
                              );
                            }
                          });
                        }
                      },
                      child: const Text('Comment'),
                    ),
                  ],
                ),

                gapH20,

                comments.isNotEmpty
                    ? ListView.builder(
                        shrinkWrap: true,
                        physics:
                            const NeverScrollableScrollPhysics(), // to disable ListView's scrolling
                        itemCount: comments.length,
                        itemBuilder: (context, index) {
                          Comment comment = comments[index];
                          return ListTile(
                            title: Text(
                              comment.writer.userName,
                              style: const TextStyle(
                                color: Colors.white54,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Text(
                              comment.comment,
                              style: const TextStyle(
                                color: Colors.white,
                              ),
                            ),
                            trailing: Visibility(
                              visible: comment.writer.userId == currentUser?.id,
                              child: IconButton(
                                onPressed: () async {
                                  final authServices =
                                      ref.read(authServiceProvider);
                                  String? token = authServices.token;

                                  bool isDeleted = await ref
                                      .read(specimenProvider)
                                      .deleteComment(comment.id, token ?? '');

                                  if (!context.mounted) {
                                    return;
                                  }

                                  // Navigator.of(context).pop();

                                  if (isDeleted) {
                                    ref.invalidate(specimenDataProvider);

                                    // Find the comment in the list by ID and remove it
                                    setState(() {
                                      comments.removeWhere(
                                          (c) => c.id == comment.id);
                                    });
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text(
                                            "Comment deleted successfully."),
                                      ),
                                    );
                                    // Navigator.of(context).pop();
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text(
                                            "Failed to delete the comment."),
                                      ),
                                    );
                                  }
                                },
                                icon: const Icon(
                                  Icons.delete,
                                ),
                              ),
                            ),
                          );
                        },
                      )
                    : const Center(child: Text('Oops, no comments found!')),
              ],
            ),
          ),
        ),
      );
    });
  }
}

String formatDateTime(String createdAt) {
  final dateTime = DateTime.parse(createdAt);
  final formattedDate = DateFormat('dd/MM/yyyy').format(dateTime);
  return formattedDate;
}
