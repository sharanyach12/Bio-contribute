import 'package:bio_contribute/src/config/config.dart';
import 'package:bio_contribute/src/constants/input_decorations.dart';
import 'package:bio_contribute/src/constants/size_box.dart';
import 'package:bio_contribute/src/models/specimen.dart';
import 'package:bio_contribute/src/provider/specimen_provider.dart';
import 'package:bio_contribute/src/screens/home/screens/list_screens/specimen_details.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../themes/colors.dart';

class ListScreen extends StatefulWidget {
  const ListScreen({super.key});

  @override
  State<ListScreen> createState() => _ListScreenState();
}

class _ListScreenState extends State<ListScreen> {
  String searchTerm = '';
  @override
  Widget build(BuildContext context) {
    return Consumer(builder: (context, ref, child) {
      final specimenData = ref.watch(specimenDataProvider);
      return Scaffold(
        appBar: AppBar(
          title: TextField(
            onChanged: (value) {
              setState(() {
                searchTerm = value.toLowerCase();
              });
            },
            decoration: searchDecoration(),
            style: const TextStyle(color: Colors.white),
          ),
          centerTitle: true,
          automaticallyImplyLeading: false,
          backgroundColor: myBackGroundColor,
          foregroundColor: Colors.white,
        ),
        body: specimenData.when(
          loading: () {
            return const Center(
              child: CircularProgressIndicator(),
            );
          },
          error: (error, stackTrace) {
            return Text(error.toString());
          },
          data: (thisSpecimenData) {
            // Filter specimens based on search term
            var filteredSpecimens = searchTerm.isEmpty
                ? thisSpecimenData
                : thisSpecimenData.where((specimen) {
                    return specimen.name.toLowerCase().contains(searchTerm) ||
                        specimen.description.toLowerCase().contains(searchTerm);
                  }).toList();

            // Display "not found" message if no specimens match the search term
            if (filteredSpecimens.isEmpty) {
              return const Center(child: Text('Oops, not found!'));
            }

            return ListView.builder(
              itemCount: filteredSpecimens.length,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                Specimen specimen = filteredSpecimens[index];
                // print(specimen.imageUrl);
                return GestureDetector(
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) {
                      return SpecimenDetails(
                        specimen: specimen,
                        heroTag: specimen.id.toString(),
                      );
                    }));
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          width: 0.5,
                          color: Colors.white24,
                        ),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            height: 140,
                            width: double.infinity,
                            child: ClipRRect(
                              borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                              ),
                              child: Hero(
                                tag: specimen.id.toString(),
                                child: CachedNetworkImage(
                                  imageUrl: "$baseUrl${specimen.imageUrl}",
                                  progressIndicatorBuilder:
                                      (context, url, downloadProgress) =>
                                          Center(
                                    child: CircularProgressIndicator(
                                        value: downloadProgress.progress),
                                  ),
                                  errorWidget: (context, url, error) =>
                                      const Icon(Icons.error),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                gapH5,
                                Text(
                                  specimen.name,
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                gapH5,
                                Text(
                                  specimen.description,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      );
    });
  }
}
