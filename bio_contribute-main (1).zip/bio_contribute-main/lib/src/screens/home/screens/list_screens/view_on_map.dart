import 'dart:developer';

import 'package:bio_contribute/src/config/config.dart';
import 'package:bio_contribute/src/themes/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../../../constants/input_decorations.dart';
import '../../../../constants/size_box.dart';

class ViewonMap extends StatefulWidget {
  const ViewonMap({super.key, required this.latitude, required this.longitude});
  final double latitude;
  final double longitude;

  @override
  State<ViewonMap> createState() => _ViewonMapState();
}

class _ViewonMapState extends State<ViewonMap> {
  LatLng? _passedMarkerLocation;
  LatLng? _userMarkerLocation;
  final _locationController = TextEditingController();
  List<LatLng> polylineCoordinates = [];

  @override
  void initState() {
    super.initState();

    // Set the initial marker location based on the passed latitude and longitude
    _passedMarkerLocation = LatLng(widget.latitude, widget.longitude);
    _getDecodedLocation();

    _initializeLocation();
  }

  void _getDecodedLocation() async {
    final List<Placemark> placemarks = await placemarkFromCoordinates(
      _passedMarkerLocation?.latitude ?? 37.423,
      _passedMarkerLocation?.longitude ?? -122.084,
    );
    _locationController.text = placemarks.first.name ?? '';
  }

// Change the function name to clarify its purpose
  void _initializeLocation() async {
    final permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      final newPermission = await Geolocator.requestPermission();
      if (newPermission == LocationPermission.denied) {
        // Location permissions are denied, set default coordinates to Googleplex
        setState(() {
          _userMarkerLocation = const LatLng(37.4219999, -122.0840575);
        });
      } else {
        // Location permission granted, get the user's current position
        final position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
        );
        final latitude = double.parse(position.latitude.toStringAsFixed(6));
        final longitude = double.parse(position.longitude.toStringAsFixed(6));

        setState(() {
          _userMarkerLocation = LatLng(latitude, longitude);
        });

        getPolyPoints();
      }
    } else {
      // Location permission already granted, get the user's current position
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      final latitude = double.parse(position.latitude.toStringAsFixed(6));
      final longitude = double.parse(position.longitude.toStringAsFixed(6));

      setState(() {
        _userMarkerLocation = LatLng(latitude, longitude);
      });

      getPolyPoints();
    }
  }

  void getPolyPoints() async {
    PolylinePoints polylinePoints = PolylinePoints();

    try {
      PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
        googleApiKey,
        PointLatLng(
          _userMarkerLocation!.latitude,
          _userMarkerLocation!.longitude,
        ),
        PointLatLng(
          _passedMarkerLocation!.latitude,
          _passedMarkerLocation!.longitude,
        ),
      );

      if (context.mounted) {
        // Check if the widget is still mounted
        if (result.points.isNotEmpty) {
          for (var point in result.points) {
            polylineCoordinates.add(LatLng(point.latitude, point.longitude));
          }
          setState(() {});
        } else {
          // Handle the case where no points were returned
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Unable to calculate the route.'),
            ),
          );
        }
      }
    } catch (e) {
      if (context.mounted) {
        // Check if the widget is still mounted
        // Handle any errors that occur during the calculation
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('An error occurred: $e'),
          ),
        );
      }
      log(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                            height: 40,
                            width: 40,
                            child: IconButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              icon: const Icon(Icons.arrow_back),
                            ),
                          ),
                          SizedBox(
                            width: 260,
                            child: TextFormField(
                              controller: _locationController,
                              enabled: false,
                              decoration: tFieldMapsDecoration(
                                  prefixIcon: const Icon(Icons.location_on)),
                            ),
                          ),
                          gapW10,
                        ],
                      ),
                      gapH10,
                    ],
                  ),
                ),
                Expanded(
                  child: GoogleMap(
                    mapType: MapType.normal,
                    initialCameraPosition: CameraPosition(
                      // Set Google HQ location as the initial camera position
                      target: _passedMarkerLocation ??
                          const LatLng(37.4219999, -122.0840575), // Googleplex
                      zoom: 10,
                    ),
                    polylines: {
                      Polyline(
                        polylineId: const PolylineId('route'),
                        points: polylineCoordinates,
                        color: myBackGroundColor,
                        width: 5,
                      ),
                    },
                    markers: <Marker>{
                      // User location
                      Marker(
                        markerId: const MarkerId('your location'),
                        position: _userMarkerLocation ??
                            const LatLng(37.4219999, -122.0840575),
                        infoWindow: const InfoWindow(
                          title: 'your location',
                        ),
                        draggable: false,
                      ),
                      // Specimen location
                      Marker(
                        markerId: const MarkerId('specimenLocation'),
                        position: _passedMarkerLocation ??
                            const LatLng(37.4219999, -122.0840575),
                        infoWindow: const InfoWindow(
                          title: 'specimen location',
                        ),
                        draggable: false,
                        icon: BitmapDescriptor.defaultMarkerWithHue(
                            BitmapDescriptor.hueGreen), // Set the icon to green
                      ),
                    },
                    onMapCreated: (GoogleMapController controller) {},
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 60.0, vertical: 10),
              child: TextButton(
                style: buttonMapsStyle(),
                onPressed: () {
                  Navigator.pop(
                    context,
                  );
                },
                child: const Text('Done'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
