import 'package:bio_contribute/src/constants/input_decorations.dart';
import 'package:bio_contribute/src/constants/size_box.dart';
import 'package:bio_contribute/src/constants/text_styles.dart';
import 'package:bio_contribute/src/provider/user_provider.dart';
import 'package:bio_contribute/src/screens/home/screens/capture_screens/input_screen.dart';
import 'package:bio_contribute/src/screens/login_screen.dart';
import 'package:bio_contribute/src/services/auth_services.dart';
import 'package:bio_contribute/src/services/user_api_services.dart';
import 'package:bio_contribute/src/themes/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CaptureScreen extends ConsumerWidget {
  const CaptureScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

    final userData = ref.watch(userDataProvider);
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        title: userData.maybeWhen(
          data: (data) {
            return Text(
              "Hi ${data!.username ?? 'user'}",
            );
          },
          loading: () {
            return const Text("loading..");
          },
          orElse: () {
            return const Text("-");
          },
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.menu), // Use the menu icon to open the drawer
          onPressed: () {
            scaffoldKey.currentState?.openDrawer();
          },
        ),
        backgroundColor: myBackGroundColor,
        foregroundColor: Colors.white,
      ),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Text(
                "WELCOME",
                style: kTitleStyle,
              ),
              gapH10,
              const Text("Let's start by capturing biodiversity"),
              gapH30,
              gapH30,
              TextButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return const InputScreen();
                  }));
                },
                style: buttonStyle(),
                child: const Text(
                  "CAPTURE",
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      drawer: Drawer(
        backgroundColor: myBackGroundColor,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              decoration: const BoxDecoration(),
              accountName: userData.maybeWhen(
                data: (data) {
                  return Text(
                    data!.username ?? 'User',
                    style: const TextStyle(color: Colors.white),
                  );
                },
                loading: () {
                  return const Text(
                    "Loading...",
                    style: TextStyle(color: Colors.white),
                  );
                },
                orElse: () {
                  return const Text(
                    "Guest",
                    style: TextStyle(color: Colors.white),
                  );
                },
              ),
              currentAccountPicture: const CircleAvatar(
                // You can display the user's profile picture here
                child: Icon(Icons.person),
              ),
              accountEmail: userData.maybeWhen(
                data: (data) {
                  return Text(
                    data!.email ?? 'email',
                    style: const TextStyle(color: Colors.white),
                  );
                },
                loading: () {
                  return const Text(
                    "Loading...",
                    style: TextStyle(color: Colors.white),
                  );
                },
                orElse: () {
                  return const Text(
                    "Guest",
                    style: TextStyle(color: Colors.white),
                  );
                },
              ),
            ),
            ListTile(
              leading: const Icon(Icons.exit_to_app),
              title: const Text(
                'Sign Out',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () async {
                final prefs = await SharedPreferences.getInstance();
                await prefs.clear();
                if (context.mounted) {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (context) => const LoginScreen()));
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.exit_to_app),
              title: Text(
                'Delete Account',
                style: TextStyle(color: Colors.red[800]),
              ),
              onTap: () {
                bool isDeleting = false; // Track the delete operation state

                showDialog(
                  context: context,
                  barrierDismissible:
                      false, // Prevent dismissing dialog while loading
                  builder: (BuildContext context) {
                    return StatefulBuilder(
                      builder: (context, setState) {
                        return AlertDialog(
                          backgroundColor: myBackGroundColor,
                          title: const Text("Delete Account"),
                          content: isDeleting
                              ? const SizedBox(
                                  height: 60,
                                  child: Center(
                                    child: SpinKitRing(
                                      lineWidth: 2,
                                      color: myForeGroundColor,
                                      size: 50.0,
                                    ),
                                  ),
                                )
                              : const Text(
                                  "Are you sure you want to delete your account?"),
                          actions: <Widget>[
                            TextButton(
                              child: const Text(
                                "Cancel",
                              ),
                              onPressed: () {
                                if (!isDeleting) {
                                  Navigator.of(context).pop();
                                }
                              },
                            ),
                            TextButton(
                              child: const Text("OK"),
                              onPressed: () async {
                                setState(() {
                                  isDeleting =
                                      true; // Show the progress indicator
                                });
                                final authServices =
                                    ref.read(authServiceProvider);
                                String? token = authServices.token;

                                bool isDeleted = await ref
                                    .read(userProvider)
                                    .deleteUser(token: token ?? '');

                                if (!context.mounted) {
                                  return;
                                }

                                setState(() {
                                  isDeleting =
                                      false; // Hide the progress indicator
                                });

                                Navigator.of(context).pop();

                                if (isDeleted) {
                                  // Clear shared preferences when the account is deleted
                                  final prefs =
                                      await SharedPreferences.getInstance();
                                  await prefs.clear();
                                  if (context.mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text(
                                            "Account deleted successfully."),
                                      ),
                                    );
                                  }
                                  if (context.mounted) {
                                    Navigator.of(context).pushReplacement(
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                const LoginScreen()));
                                  }
                                } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content:
                                          Text("Failed to delete the account."),
                                    ),
                                  );
                                }
                              },
                            ),
                          ],
                        );
                      },
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
