import 'dart:developer';

import 'package:bio_contribute/src/constants/input_decorations.dart';
import 'package:bio_contribute/src/constants/size_box.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class PinonMapUpdateScreen extends StatefulWidget {
  const PinonMapUpdateScreen(
      {super.key, required this.latitude, required this.longitude});
  final double latitude;
  final double longitude;

  @override
  State<PinonMapUpdateScreen> createState() => _PinonMapUpdateScreenState();
}

class _PinonMapUpdateScreenState extends State<PinonMapUpdateScreen> {
  GoogleMapController? _mapController;
  LatLng? _markerLocation;
  final _locationController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Initialize _markerLocation with the provided latitude and longitude
    _markerLocation = LatLng(widget.latitude, widget.longitude);
    _updateCameraPosition(
        _markerLocation ?? const LatLng(37.4219999, -122.0840575));
  }

  void _updateCameraPosition(LatLng newLocation) async {
    if (_mapController != null && mounted) {
      final newCameraPosition = CameraPosition(
        target: newLocation,
        zoom: 14.5,
      );
      _mapController!
          .animateCamera(CameraUpdate.newCameraPosition(newCameraPosition));

      try {
        final List<Placemark> placemarks = await placemarkFromCoordinates(
          newLocation.latitude,
          newLocation.longitude,
        );

        if (mounted) {
          if (placemarks.isNotEmpty) {
            final Placemark placemark = placemarks.first;
            final String locationName = placemark.name ?? '';
            _locationController.text = locationName;
          } else {
            // Handle the case where no placemarks were found
            _locationController.text = 'Location not available';
          }
        }
      } catch (e) {
        // Handle the geocoding exception here
        log("Geocoding error: $e");
        _locationController.text = 'Location not available';
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    log(_markerLocation!.latitude.toString());
    log(_markerLocation!.longitude.toString());
    return Scaffold(
      body: Stack(
        children: [
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                            height: 40,
                            width: 40,
                            child: IconButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              icon: const Icon(Icons.arrow_back),
                            ),
                          ),
                          SizedBox(
                            width: 260,
                            child: TextFormField(
                              controller: _locationController,
                              enabled: false,
                              decoration: tFieldMapsDecoration(
                                  prefixIcon: const Icon(Icons.location_on)),
                            ),
                          ),
                          gapW10,
                        ],
                      ),
                      gapH10,
                      const Text(
                        "Long press and move the marker to choose location",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w300,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: GoogleMap(
                    mapType: MapType.normal,
                    initialCameraPosition: CameraPosition(
                      // Set a default location if userLocation is null
                      target: _markerLocation ??
                          const LatLng(37.4219999, -122.0840575),
                      zoom: 14.5,
                    ),
                    markers: <Marker>{
                      Marker(
                        markerId: const MarkerId('draggableLocation'),
                        position: _markerLocation ??
                            const LatLng(37.4219999, -122.0840575),
                        infoWindow: const InfoWindow(
                          title: 'Draggable Location',
                        ),
                        draggable: true,
                        onDragEnd: (LatLng newPosition) async {
                          final List<Placemark> placemarks =
                              await placemarkFromCoordinates(
                            newPosition.latitude,
                            newPosition.longitude,
                          );

                          if (placemarks.isNotEmpty) {
                            final Placemark placemark = placemarks.first;
                            final String locationName = placemark.name ?? '';

                            setState(() {
                              _markerLocation = newPosition;
                              _locationController.text = locationName;
                            });

                            // Update the camera position to follow the marker
                            _updateCameraPosition(_markerLocation ??
                                const LatLng(37.4219999, -122.0840575));
                          } else {
                            // Handle the case where no placemarks were found
                            setState(() {
                              _markerLocation = newPosition;
                              _locationController.text =
                                  'Location not available';
                            });
                          }
                        },
                      ),
                    },
                    onMapCreated: (GoogleMapController controller) {
                      _mapController = controller;
                      _updateCameraPosition(_markerLocation ??
                          const LatLng(37.4219999, -122.0840575));
                    },
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 60.0, vertical: 10),
              child: TextButton(
                style: buttonMapsStyle(),
                onPressed: () {
                  Navigator.pop(
                    context,
                    LatLng(
                        _markerLocation!.latitude, _markerLocation!.longitude),
                  );
                },
                child: const Text('Done'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
