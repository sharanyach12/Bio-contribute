import 'dart:io';

import 'package:bio_contribute/src/config/config.dart';
import 'package:bio_contribute/src/constants/size_box.dart';
import 'package:bio_contribute/src/models/specimen.dart';
import 'package:bio_contribute/src/screens/home/home_screen.dart';
import 'package:bio_contribute/src/screens/home/screens/capture_screens/update_specimen/pin_on_map.dart';
import 'package:bio_contribute/src/services/auth_services.dart';
import 'package:bio_contribute/src/services/specimen_api_services.dart';
import 'package:bio_contribute/src/themes/colors.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:image_picker/image_picker.dart';

import '../../../../../constants/input_decorations.dart';
import '../../../../../provider/specimen_provider.dart';

class UpdateScreen extends StatefulWidget {
  const UpdateScreen({super.key, required this.specimen});
  final Specimen specimen;

  @override
  State<UpdateScreen> createState() => _UpdateScreenState();
}

class _UpdateScreenState extends State<UpdateScreen> {
  @override
  void initState() {
    specimenPost = widget.specimen;

    super.initState();
    nameController.text = specimenPost.name;
    descriptionController.text = specimenPost.description;
  }

  late Specimen specimenPost;
  bool imageNull = true;
  File? image;
  ImagePicker picker = ImagePicker();
  bool displayShimer = false;
  // double? latitude;
  // double? longitude;
  TextEditingController nameController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();
  final openAI = OpenAI.instance.build(
    token: chatGptToken,
    baseOption: HttpSetup(receiveTimeout: const Duration(seconds: 30)),
    enableLog: true,
  );
  Future<void> generateDescription(String name) async {
    // clearing any text description
    descriptionController.text =
        "GPT description loading ... \n (Responses may take upto 30 seconds.)";
    final request = CompleteText(
      prompt: "Generate a description for $name",
      maxTokens: 200,
      model: TextDavinci3Model(),
    );

    try {
      final response = await openAI.onCompletion(request: request);
      final description = response?.choices.last.text;

      setState(() {
        // Update the description field with the generated content
        // (You should have a field in your Specimen object for this)

        specimenPost.description = description ?? 'Check your internet';
        descriptionController.text = specimenPost.description;
      });
    } catch (e) {
      // Handle errors
      if (e is OpenAIRateLimitError) {
        // Handle rate limit error by waiting and retrying
        await Future.delayed(const Duration(seconds: 5));
        await generateDescription(name);
        descriptionController.text =
            "Oops! Something went wrong, try again later.";
      } else {
        // Handle other errors
        descriptionController.text =
            "Oops! Something went wrong, try again later.";
      }
    }
  }

  @override
  void dispose() {
    nameController.dispose();
    descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer(builder: (context, ref, child) {
      return Scaffold(
        appBar: AppBar(
          backgroundColor: myBackGroundColor,
          foregroundColor: myForeGroundColor,
          title: const Text('Update Screen'),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                Row(
                  children: [
                    const Text(
                      'Current Image',
                    ),
                    gapW5,
                    SizedBox(
                      height: 60,
                      width: 60,
                      child: CachedNetworkImage(
                        imageUrl: baseUrl + specimenPost.imageUrl,
                        fit: BoxFit.cover,
                        placeholder: (context, url) =>
                            const CircularProgressIndicator(),
                        errorWidget: (context, url, error) {
                          return const Icon(Icons.broken_image);
                        },
                      ),
                    ),
                  ],
                ),
                gapH10,
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        // Implement logic to capture an image from the camera
                        captureImage(ImageSource.camera);
                      },
                      child: const Text("Capture Image"),
                    ),
                    gapW10,
                    ElevatedButton(
                      onPressed: () {
                        // Implement logic to select an image from the gallery
                        captureImage(ImageSource.gallery);
                      },
                      child: const Text("From Gallery"),
                    ),
                  ],
                ),
                imageNull
                    ? Container(
                        height: 180,
                        decoration: const BoxDecoration(
                          color: Colors.white10,
                          // color: Colors.white,
                          borderRadius: BorderRadius.all(Radius.circular(15.0)),
                        ),
                        child: const Center(
                          child: Icon(
                            Icons.image,
                            color: Color(0xFF6D7D8B),
                          ),
                        ),
                      )
                    : Container(
                        height: 180,
                        width: double.infinity,
                        decoration: const BoxDecoration(
                          // color: myImageContainerGrey,
                          borderRadius: BorderRadius.all(Radius.circular(15.0)),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(15.0),
                          child: Image.file(
                            File(
                              image!.path,
                            ),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                gapH20,
                const Align(
                    alignment: Alignment.bottomLeft, child: Text("Name")),
                gapH5,
                TextFormField(
                  decoration: tFieldInputDecoration(
                      inputhinttext: "e.g. Biological Name"),
                  controller: nameController,
                ),
                gapH5,
                const Text(
                  'enter an accurate name as this will assist in generating correct description, or even it\'s biological name',
                  style: TextStyle(
                    fontSize: 10,
                    color: Colors.blueGrey,
                  ),
                ),

                gapH10,
                const Align(
                    alignment: Alignment.bottomLeft,
                    child: Text("Generated Content")),
                gapH5,
                TextFormField(
                  decoration:
                      tFieldInputDecoration(inputhinttext: "GPT Description"),
                  controller: descriptionController,
                  minLines: 4,
                  maxLines: 8,
                ),
                gapH20,
                TextButton(
                  onPressed: () {
                    // Get the name from the controller
                    final name = nameController.text;

                    // Generate the description using GPT-3
                    if (name.isNotEmpty) {
                      generateDescription(name);
                    }
                  },
                  style: buttonStyleTwo(),
                  child: const Text(
                    "Generate Content",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                gapH20,
                // Pin on map
                InkWell(
                  onTap: () async {
                    final LatLng? result = await Navigator.push(context,
                        MaterialPageRoute(builder: (builder) {
                      return PinonMapUpdateScreen(
                        latitude: specimenPost.latitude ?? 37.422,
                        longitude: specimenPost.longitude ?? -122.084,
                      );
                    }));

                    if (result != null) {
                      setState(() {
                        specimenPost.latitude = result.latitude;
                        specimenPost.longitude = result.longitude;
                      });
                    }
                  },
                  child: Container(
                    height: 55,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      image: const DecorationImage(
                        image: AssetImage("assets/images/pin_on_map.png"),
                        fit: BoxFit.cover,
                      ),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.location_on_outlined,
                          color: Colors.white,
                        ),
                        gapW5,
                        Text(
                          "pin on map",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                gapH30,
                TextButton(
                  onPressed: () {
                    if (nameController.text.isEmpty) {
                      // Show a SnackBar if the name is empty
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("Name cannot be empty."),
                        ),
                      );
                    } else if (specimenPost.latitude == 0 ||
                        specimenPost.longitude == 0) {
                      // Show a SnackBar if latitude or longitude is 0
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content:
                              Text("Please choose coordinates on the map."),
                        ),
                      );
                    } else if (specimenPost.description == '') {
                      // Show a SnackBar if latitude or longitude is 0
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                              "GPT description can't be empty. Also, description must be generated by chatGPT."),
                        ),
                      );
                    } else {
                      // If both name and image are valid, proceed with the post operation
                      showDialog(
                        context: context,
                        builder: (context) => const AlertDialog(
                          backgroundColor: myBackGroundColor,
                          content: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SpinKitRing(
                                color: myForeGroundColor,
                                lineWidth: 2,
                              ),
                              SizedBox(height: 16),
                              Text("Updating Specimen..."),
                            ],
                          ),
                        ),
                        barrierDismissible: false,
                      );

                      // Update the specimenPost object with the relevant fields
                      specimenPost.name = nameController.text; // Update name
                      // Update imageUrl

                      // Gain access to the token
                      final authServices = ref.read(authServiceProvider);
                      String? token = authServices.token;

                      // Call the postSpecimen method
                      ref
                          .read(specimenProvider)
                          .updateSpecimen(specimenPost, image, token ?? '')
                          .then((success) {
                        // Dismiss loading dialog
                        Navigator.of(context).pop();

                        // Handle the result
                        if (success) {
                          // Navigate to the home screen on success
                          ref.invalidate(specimenDataProvider);
                          Navigator.of(context).pushReplacement(
                              MaterialPageRoute(builder: ((context) {
                            return const HomeScreen();
                          })));
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              backgroundColor: Colors.green,
                              content: Text("Updated Specimen Successfully!"),
                            ),
                          );
                        } else {
                          // Handle the failure, you can show an error message here
                          // or handle it as per your requirements
                          // For example, show a SnackBar with an error message
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content:
                                  Text("Updating failed. Please try again."),
                            ),
                          );
                        }
                      });
                    }
                  },
                  style: buttonStyle(),
                  child: const Text(
                    "Submit",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    });
  }

  // Create a new method to handle image capture/select
  Future<void> captureImage(ImageSource source) async {
    displayShimer = true;
    var pickedImage = await picker.pickImage(source: source);

    setState(() {
      if (pickedImage != null) {
        image = File(pickedImage.path);
        imageNull = false;
        displayShimer = true;
      } else {
        // Handle the case where no image is selected
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('No image selected'),
          ),
        );
        imageNull = true;
        displayShimer = false;
      }
    });
  }
}
