import 'package:bio_contribute/src/screens/home/home_screen.dart';
import 'package:bio_contribute/src/services/auth_services.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final authNotifierProvider = StateNotifierProvider<AuthNotifier, bool>(
    (ref) => AuthNotifier(ref.watch(authServiceProvider)));

class AuthNotifier extends StateNotifier<bool> {
  final AuthServices _authServices;
  AuthNotifier(this._authServices) : super(false);

  login({
    required String email,
    required String password,
    required BuildContext context,
  }) async {
    try {
      state = true;
      final result =
          await _authServices.login(email: email, password: password);

      if (result.success) {
        if (!mounted) return;
        Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => const HomeScreen()));
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result.message),
          ),
        );
      }
      state = false;
    } catch (e) {
      state = false;
    }
  }

  register({
    required String username,
    required String email,
    required String password,
    required BuildContext context,
  }) async {
    try {
      state = true;
      final result = await _authServices.register(
          email: email, password: password, username: username);

      if (result.success) {
        if (!mounted) return;
        Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => const HomeScreen()));
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result.message),
          ),
        );
      }
      state = false;
    } catch (e) {
      state = false;
    }
  }
}
