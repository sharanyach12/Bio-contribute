import 'package:bio_contribute/src/services/specimen_api_services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final specimenDataProvider =
    FutureProvider((ref) => ref.watch(specimenProvider).getAllSpecimen());
