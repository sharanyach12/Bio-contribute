import 'package:bio_contribute/src/services/auth_services.dart';
import 'package:bio_contribute/src/services/user_api_services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/user.dart';

// final userDataProvider =
//     FutureProvider((ref) => ref.watch(userProvider).getUser(ref: ref));
final userDataProvider = FutureProvider<User?>((ref) async {
  final userApiServices = ref.read(userProvider);
  final authServices = ref.read(authServiceProvider);

  if (authServices.isLoggedIn) {
    final token = authServices.token;
    return await userApiServices.getUser(token: token!);
  }

  return null; // Return null if the user is not authenticated
});
