import 'package:flutter/material.dart';

const Color myForeGroundColor = Color(0xffCCCB31);
const Color myBackGroundColor = Color(0xff0E1030);
const Color myinputBorderColor = Color(0xffDADADA);
