import 'package:bio_contribute/src/themes/colors.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Mytheme {
  static final appTheme = ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: myBackGroundColor,
    primaryColor: myForeGroundColor,
    // brightness: Brightness.dark,
    textTheme: GoogleFonts.loraTextTheme().apply(
      bodyColor: Colors.white, // Set the overall text color to white
    ),
    // colorScheme: ColorScheme.fromSeed(seedColor: myBackGroundColor),
    // colorScheme: const ColorScheme.dark(primary: myBackGroundColor),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        foregroundColor: Colors.white,
        backgroundColor:
            myForeGroundColor, // Set button text (foreground) color to white
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: myBackGroundColor, // button text color
        backgroundColor: myForeGroundColor, // button background color
      ),
    ),
  );
}
