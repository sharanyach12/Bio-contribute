const baseUrl = 'https://biocontribute.pythonanywhere.com';

const chatGptToken = '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';
const googleApiKey = 'AIzaSyAxltSWTAnljVy0arETrKlcgG1J4srQabM';
