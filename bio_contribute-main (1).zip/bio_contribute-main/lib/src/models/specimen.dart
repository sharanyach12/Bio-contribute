import 'package:bio_contribute/src/models/comment.dart';

class Specimen {
  int? id;
  String name;
  String imageUrl;
  Creator? creator;
  String description;
  double? latitude;
  double? longitude;
  DateTime? createdAt;
  List<Comment>? comments;

  Specimen({
    this.id,
    required this.name,
    required this.imageUrl,
    this.creator,
    required this.description,
    this.latitude,
    this.longitude,
    this.createdAt,
    this.comments,
  });

  factory Specimen.fromJson(Map<String, dynamic> json) {
    var commentList = json['comments'] as List;
    List<Comment> comments =
        commentList.map((i) => Comment.fromJson(i)).toList();

    return Specimen(
      id: json['id'],
      name: json['name'],
      imageUrl: json['image'],
      creator:
          json['creator'] != null ? Creator.fromJson(json['creator']) : null,
      description: json['description'],
      latitude: json['latitude'],
      longitude: json['longitude'],
      createdAt: DateTime.parse(json['created_at']),
      comments: comments,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'image': imageUrl,
      'creator': creator?.toJson(),
      'description': description,
      'latitude': latitude,
      'longitude': longitude,
      'created_at': createdAt?.toIso8601String(),
      'comments': comments?.map((i) => i.toJson()).toList(),
    };
  }
}

class Creator {
  final String authorName;
  final String authorEmailAddress;

  Creator({
    required this.authorName,
    required this.authorEmailAddress,
  });

  factory Creator.fromJson(Map<String, dynamic> json) {
    return Creator(
      authorName: json['author_name'],
      authorEmailAddress: json['author_email_address'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'author_name': authorName,
      'author_email_address': authorEmailAddress,
    };
  }
}
