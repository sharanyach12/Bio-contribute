class User {
  int? id;
  String? username;
  String? email;
  String? password;
  String? token;

  User({this.id, this.username, this.email, this.password, this.token});

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    username = json['username'];
    email = json['email_address'];
    password = json['password'];
    token = json['token'];
  }

  Map<String, dynamic> toJson() {
    // Below unnecessary constructor invocation
    // final Map<String, dynamic> data = Map<String, dynamic>();
    final Map<String, dynamic> data = <String, dynamic>{};

    data['id'] = id;
    data['username'] = username;
    data['email_address'] = email;
    data['password'] = password;
    data['token'] = token;
    return data;
  }
}
