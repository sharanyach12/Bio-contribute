class Comment {
  String id;
  String comment;
  Writer writer;
  SpecimenAttached specimenAttached;

  Comment({
    required this.id,
    required this.comment,
    required this.writer,
    required this.specimenAttached,
  });

  factory Comment.fromJson(Map<String, dynamic> json) {
    return Comment(
      id: json['id'],
      comment: json['comment'],
      writer: Writer.fromJson(json['writer']),
      specimenAttached: SpecimenAttached.fromJson(json['specimen_attached']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'comment': comment,
      'writer': writer.toJson(),
      'specimen_attached': specimenAttached.toJson(),
    };
  }
}

class Writer {
  int userId;
  String userName;

  Writer({
    required this.userId,
    required this.userName,
  });

  factory Writer.fromJson(Map<String, dynamic> json) {
    return Writer(
      userId: json['user_id'],
      userName: json['user_name'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'user_id': userId,
      'user_name': userName,
    };
  }
}

class SpecimenAttached {
  int specimenId;
  String specimenName;

  SpecimenAttached({
    required this.specimenId,
    required this.specimenName,
  });

  factory SpecimenAttached.fromJson(Map<String, dynamic> json) {
    return SpecimenAttached(
      specimenId: json['specimen_id'],
      specimenName: json['specimen_name'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'specimen_id': specimenId,
      'specimen_name': specimenName,
    };
  }
}
