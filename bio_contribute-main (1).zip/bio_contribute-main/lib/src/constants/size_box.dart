import 'package:flutter/material.dart';

// Width
const gapW5 = SizedBox(width: 5);
const gapW10 = SizedBox(width: 10);
const gapW15 = SizedBox(width: 15);
const gapW20 = SizedBox(width: 20);
const gapW30 = SizedBox(width: 30);

// Hight
const gapH5 = SizedBox(height: 5);
const gapH10 = SizedBox(height: 10);
const gapH20 = SizedBox(height: 20);
const gapH30 = SizedBox(height: 30);
