import 'package:bio_contribute/src/themes/colors.dart';
import 'package:flutter/material.dart';

InputDecoration tFieldInputDecoration({
  inputhinttext,
  suffixIcon,
}) {
  return InputDecoration(
    hintStyle: const TextStyle(color: Colors.grey),
    hintText: inputhinttext,
    suffixIcon: suffixIcon,
    filled: true,
    fillColor: Colors.white12,
    labelStyle: const TextStyle(
      color: Colors.black,
    ),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(20),
      borderSide: const BorderSide(color: Color(0xFFBBC8D4), width: .0),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(20),
      borderSide: const BorderSide(color: Color(0xFfBBC8D4), width: 0.0),
    ),
    focusedBorder: OutlineInputBorder(
      gapPadding: 0.0,
      borderRadius: BorderRadius.circular(20),
      borderSide: const BorderSide(color: myForeGroundColor, width: 0.0),
    ),
  );
}

ButtonStyle buttonStyle() {
  return ButtonStyle(
    backgroundColor: MaterialStateProperty.all<Color>(myForeGroundColor),
    // foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
    padding: const MaterialStatePropertyAll(
        EdgeInsets.symmetric(horizontal: 40.0, vertical: 10.0)),
    // minimumSize:
    //     MaterialStateProperty.all<Size>(const Size(double.infinity, 50)),
    shape: MaterialStateProperty.all<OutlinedBorder>(
      RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(25.0),
      ),
    ),
  );
}

ButtonStyle buttonStyleTwo() {
  return ButtonStyle(
    backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
    foregroundColor: MaterialStateProperty.all<Color>(myBackGroundColor),
    padding: const MaterialStatePropertyAll(
        EdgeInsets.symmetric(horizontal: 40.0, vertical: 10.0)),
    // minimumSize:
    //     MaterialStateProperty.all<Size>(const Size(double.infinity, 50)),
    shape: MaterialStateProperty.all<OutlinedBorder>(
      RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(25.0),
      ),
    ),
  );
}

ButtonStyle buttonStyleEdit() {
  return ButtonStyle(
    backgroundColor: MaterialStateProperty.all<Color>(Colors.white24),
    foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
    padding: const MaterialStatePropertyAll(
        EdgeInsets.symmetric(horizontal: 40.0, vertical: 10.0)),
    // minimumSize:
    //     MaterialStateProperty.all<Size>(const Size(double.infinity, 50)),
    shape: MaterialStateProperty.all<OutlinedBorder>(
      RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(25.0),
      ),
    ),
  );
}

ButtonStyle buttonStyleDialog() {
  return ButtonStyle(
    backgroundColor: MaterialStateProperty.all<Color>(Colors.white24),
    foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
    padding: const MaterialStatePropertyAll(
        EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0)),
    // minimumSize:
    //     MaterialStateProperty.all<Size>(const Size(double.infinity, 50)),
    shape: MaterialStateProperty.all<OutlinedBorder>(
      RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(25.0),
      ),
    ),
  );
}

ButtonStyle buttonMapsStyle() {
  return ButtonStyle(
    backgroundColor: MaterialStateProperty.all<Color>(myBackGroundColor),
    foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
    minimumSize:
        MaterialStateProperty.all<Size>(const Size(double.infinity, 50)),
    shape: MaterialStateProperty.all<OutlinedBorder>(
      RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
      ),
    ),
  );
}

InputDecoration tFieldMapsDecoration(
    {prefixIcon, inputlabeltext, inputhinttext, suffixIcon}) {
  return InputDecoration(
    floatingLabelBehavior: FloatingLabelBehavior.always,
    hintText: inputhinttext,
    prefixIcon: prefixIcon,
    suffixIcon: suffixIcon,
    hintStyle: const TextStyle(
      fontFamily: 'Inter',
      fontSize: 16.0,
      fontWeight: FontWeight.w400,
      color: Colors.grey,
    ),
    contentPadding:
        const EdgeInsets.symmetric(vertical: 10.0, horizontal: 16.0),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: myinputBorderColor, width: 0.50),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: myinputBorderColor, width: 0.5),
    ),
    disabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: myinputBorderColor, width: 0.5),
    ),
    focusedBorder: OutlineInputBorder(
      gapPadding: 0.0,
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: myForeGroundColor, width: 0.8),
    ),
  );
}

// Serch Decorations
InputDecoration searchDecoration() {
  return InputDecoration(
    hintText: 'Search',
    hintStyle: const TextStyle(color: Colors.white),
    contentPadding:
        const EdgeInsets.symmetric(vertical: 10.0, horizontal: 16.0),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: myinputBorderColor, width: 0.50),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: myinputBorderColor, width: 0.5),
    ),
    disabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: myinputBorderColor, width: 0.5),
    ),
    focusedBorder: OutlineInputBorder(
      gapPadding: 0.0,
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(color: myForeGroundColor, width: 0.8),
    ),
  );
}

// add Comment Decoration
InputDecoration addCommentDecoration() {
  return InputDecoration(
    hintText: 'Add a comment...',
    hintStyle: const TextStyle(color: Colors.white),
    contentPadding:
        const EdgeInsets.symmetric(vertical: 10.0, horizontal: 16.0),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(20),
      borderSide: const BorderSide(color: myinputBorderColor, width: 0.50),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(20),
      borderSide: const BorderSide(color: myinputBorderColor, width: 0.5),
    ),
    disabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(20),
      borderSide: const BorderSide(color: myinputBorderColor, width: 0.5),
    ),
    focusedBorder: OutlineInputBorder(
      gapPadding: 0.0,
      borderRadius: BorderRadius.circular(20),
      borderSide: const BorderSide(color: myForeGroundColor, width: 0.8),
    ),
  );
}
