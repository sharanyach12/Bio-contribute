import 'package:flutter/material.dart';

const kTitleStyle = TextStyle(
  fontSize: 32.0,
  fontWeight: FontWeight.w400,
);
