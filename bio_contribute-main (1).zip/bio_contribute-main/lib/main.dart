import 'package:bio_contribute/src/screens/home/home_screen.dart';
import 'package:bio_contribute/src/screens/login_screen.dart';
import 'package:bio_contribute/src/services/auth_services.dart';
import 'package:bio_contribute/src/themes/themes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

Future<void> main() async {
  WidgetsFlutterBinding
      .ensureInitialized(); // Ensure WidgetsBinding is initialized

  final authServices = AuthServices();
  await authServices.getTokenFromSharedPreferences();

  runApp(
    ProviderScope(
      overrides: [
        authServiceProvider.overrideWithValue(authServices),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends ConsumerWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final token = ref.watch(authServiceProvider).token;

    return MaterialApp(
      title: 'Flutter Demo',
      theme: Mytheme.appTheme,
      home: token != null ? const HomeScreen() : const LoginScreen(),
    );
  }
}
