package com.example.bio_contribute

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
